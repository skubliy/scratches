#ifndef SHM_IP_HOLDER_H_INCLUDED
#define SHM_IP_HOLDER_H_INCLUDED

//#include "flags_wrap.hpp"
#include "ip_wrap.hpp"

#define MAX_VAP 64
#define MAX_IP_PER_VAP 8


typedef std::list<ip_wrap> new_ip_list_t;

void update_ip_array(new_ip_list_t& new_ip_list, int id);

void owner_do_test();

#endif
