
#ifndef SHM_2D_ARR_HPP_INCLUDED
#define SHM_2D_ARR_HPP_INCLUDED

#ifndef LOG
#include <stdio.h>
#define LOG fprintf
#define LOG_DEBUG stdout
#define LOG_ERROR stderr
#endif

#ifndef nullptr
#define nullptr NULL
#endif


//#include <sys/mman.h>   // shm_open
//#include <sys/stat.h>   // fstat, stat ...
//#include <unistd.h>     // ftruncate
//#include <fcntl.h>      // definition of O_XX constants: O_RDONLY, O_RDWR, O_CREATE ...
//#include <string.h>     // strlen
//#include <errno.h>      // errno

#include "shm_obj.hpp"

#include <list>

#define time_not_expaired 1 //TODO zzz


template <typename TV, typename TD, typename TF, size_t MAX_ID, size_t MAX_IDX>
class shm_arr_hholder {

    template <typename _TI, size_t _MAX_ITEM>
    class arr_wrap {
        typedef arr_wrap<_TI, _MAX_ITEM> __Tslf;
        typedef _TI*    __TIptr;
        typedef _TI&    __TIref;
        typedef _TI     __TIarr[_MAX_ITEM];
        typedef __TIarr& __TIarr_ref;
        typedef __TIarr* __TIarr_ptr;

        __TIarr _arr;

    public:
        //TODO public for now
        __TIref operator[](size_t id) {
            LOG( LOG_DEBUG, "operator1 %lu sz=%lu\n", id, sizeof(__TIarr) );
            return _arr[id];
        }
        //TODO it is public for now
        operator __TIarr_ref() {
            return (_arr);
        }

        operator __TIarr_ptr() {
            return (&_arr[0]);
        }

        operator __TIptr() {
            return (&_arr[0]);
        }
    };

public:
    typedef arr_wrap<TV, MAX_IDX> vers_arr_t;
    typedef arr_wrap<TD, MAX_IDX> vals_arr_t;
    typedef arr_wrap<TF, MAX_IDX> flgs_arr_t;

    typedef arr_wrap<vers_arr_t, MAX_ID> all_vers_t;
    typedef arr_wrap<vals_arr_t, MAX_ID> all_vals_t;
    typedef arr_wrap<flgs_arr_t, MAX_ID> all_flgs_t;

private:


    template <typename _TI, size_t _MAX_ITEM>
    class rarr_rdo {
        typedef _TI     __TIarr[_MAX_ITEM];
        __TIarr& _rarr;

    public:
        rarr_rdo(__TIarr& _ra): _rarr(_ra) {}
        _TI operator[](size_t id) const { //TODO const?
            LOG( LOG_DEBUG, "zzz rdo operator[] const %d \n", id );
            return _rarr[id];
        }
    };

public:
    typedef rarr_rdo<TV, MAX_IDX> rvers_t;
    typedef rarr_rdo<TD, MAX_IDX> rvals_t;
    typedef rarr_rdo<TF, MAX_IDX> rflgs_t;

    class shm_refs_arr {

    public:
        vers_arr_t& rvers;
        vals_arr_t& rvals;
        flgs_arr_t& rflgs;

        shm_refs_arr(vers_arr_t& _rvers, vals_arr_t& _rvals, flgs_arr_t& _rflgs) :
            rvers(_rvers), rvals(_rvals), rflgs(_rflgs)  {
        }

        shm_refs_arr(rvers_t _rvers, rvals_t _rvals, rflgs_t _rflgs) :
            rvers(_rvers), rvals(_rvals), rflgs(_rflgs)  {
        }

        shm_refs_arr(const shm_refs_arr& _ra) :
            rvers(_ra.rvers), rvals(_ra.rvals), rflgs(_ra.rflgs)  {
        }

    };

    class shm_arrays {

    public:
        shm_obj<all_vers_t> vers;
        shm_obj<all_vals_t> vals;
        shm_obj<all_flgs_t> flgs;

        shm_arrays(const char* suffix, int flags=O_RDONLY ) :
            vers( "vers-", suffix, flags ),
            vals( "vals-", suffix, flags ),
            flgs( "flgs-", suffix, flags | O_RDWR )  {
        }

        virtual ~shm_arrays() {
        }

        const shm_refs_arr operator[](size_t id) const {
            shm_refs_arr _trarr(((all_vers_t&)vers)[id], ((all_vals_t&)vals)[id], ((all_flgs_t&)flgs)[id]);
            return _trarr;
        }

    };

    class shm_data_reader  {
        shm_refs_arr rarr;
    public:
        shm_data_reader(const shm_refs_arr _rarr):
            rarr(_rarr) {}

    private:
        //TD value(size_t id, size_t n) const {
        //    return (reinterpret_cast<vap_data_arr_t*>(shmo_data_arr.mmapPtr)[id])[n];
        //};
        TD get_valid_data_by_num(size_t n) {
            //TODO need check type of version_holder it is must beatomic for now,
            // may we do it non atomic, volotile for example?
            TV version_before = rarr.rvers[n]; //it is atomic copy assignment
            if (version_before & 1) // If not even, the value in process of changing right now.
                return __zero();

            TD data = rarr.rvals[n];
            TF version_after = rarr.rvers[n]; // it is atomic copy assignment

            if  (version_before != version_after)  // versions is not sames
                // we may add extra check of version evenest
                //OR  (version_after & 1) //or versions is not even value is not correct
                return __zero();
            return data;
        }

        TD get_valid_val() {
            while(time_not_expaired) { //TODO zzz
                for (size_t n = 0; n < MAX_IDX; n++) {
                    TD data = get_valid_data_by_num(n);
                    if ( data != __zero())
                        return data;
                }
                //never happened
                //TODO zzz
            }
            return __zero(); // or some server_down_ip ;)
        }

    public:
        TD check_or_get_new_val(TD cur_val, size_t n) {
            if ( !(rarr.rflgs[n]) )
                if (cur_val == rarr.rvals[n]) // maybe need copy but I think it's not necessary
                    return cur_val;
            return get_valid_val();
        }

    private:
        TD __zero() {
            static TD __zero_data((unsigned int)0);
            return __zero_data;
        }

    };

    class shm_data_writer  {
        typedef std::list<TD*> new_vals_list;
        typedef typename std::list<TD*>::iterator new_vals_list_iter;
        //typename new_vals_list::iterator>
        shm_refs_arr rarr;
    public:
        shm_data_writer(const shm_refs_arr _rarr):
            rarr(_rarr) {}

        void update_vals_array(new_vals_list _new_vals, size_t id) {
            //TODO zzz-elb-dns temporary solution and algorithm
            // In future it will be separated method of ip_wrap_array class
            // marge_with_new_ip_list as example

            // Look for those IPs that have not changed
            // in 99.999% it will be all of them
            for ( int ii = 0; ii < MAX_IDX; ii++ ) {
                TD* ptr = NULL;
                for ( new_vals_list_iter i = _new_vals.begin(); i != _new_vals.end(); ) {
                    if (**i == rarr.rvals[ii] ) {
                        //IP is valid
                        //TODO zzz-elb-dns here check if IP was marked as bad if so reset bad_ip_flag
                        // or just reset it
                        // bad_ip_flags[vap.id][ii] = 0;
                        ptr = *i;
                        i = _new_vals.erase( i );
                        break;
                    } else {
                        ++i;
                    }
                }
                if ( ptr != NULL) {
                    delete ptr;
                } else {
                    //TODO zzz-elb-dns set bad_ip_flag for ip_arr[ii]
                    // bad_ip_flags[vap.id][ii] = -1;
                }
            }
            LOG( LOG_DEBUG, "zzz-elb-dns updateVapWithFqdn: %lu \"fresh\" IPs in new_ip_list", _new_vals.size());

            // Look for those IPs that wasn't in the previous list
            for ( new_vals_list_iter i = _new_vals.begin(); i != _new_vals.end();) {
                TD* ptr = NULL;
                for ( int ii = 0; ii < MAX_IDX; ++ii) {
                    if (  rarr.rvals[ii] == 0 ) { // || bad_ip_flags[vap.id][ii] ) { //TODO zzz-elb-dns
                        rarr.rvals[ii] = **i; //TODO zzz-elb-dns it is copy assigned. need: ip_wrap& operator = (ip_wrap* _pip)
                        // bad_ip_flags[vap.id][ii] = 0;
                        ptr = *i;
                        break;
                    }
                }

                if (ptr != NULL || *ptr != 0) {
                    LOG( LOG_DEBUG, "zzz-elb-dns updateVapWithFqdn: erasing ip %s",((std::string)*ptr).c_str());
                    i = _new_vals.erase( i );
                    delete (ptr);
                } else {
                    ++i;
                }
            }
        }

    };

    /*
        class shm_data_writer2 : public shm_arrays {
        public:
            shm_data_writer2(const char* suffix, size_t flags = O_RDWR):
                shm_arrays(suffix, flags ) {}
            virtual ~shm_data_writer2() {}

            void set_value (const TD& new_val, size_t id, size_t n) {
                if ( this->flag[id][n]) {  // in real code this check will be not here but will have same sense
                    this->vers[id][n] ++; //it is increment of atomic var version and version become NOT even
                    this->vals[id][n] = new_val;   //it  copy assignment
                    this->vers[id][n] ++; //it is increment of atomic var version and version become even
                    this->flgs[id][n] = 0;
                }
                return *this;

            };

            }
        };

    */

public:
    //    shm_arr_hholder& instance()
private:

public:
    shm_arrays* pInstance;
    shm_arr_hholder(const char* suffix, int flags=O_RDONLY) : pInstance(nullptr) {
            pInstance= new shm_arrays(suffix, flags);
    }

    ~shm_arr_hholder() {
        if (pInstance) {
            delete(pInstance);
            pInstance = nullptr;
        }
    };

};

#endif
