#ifndef SHM_2DARR_HPP_INCLUDED
#define SHM_2DARR_HPP_INCLUDED

#ifndef LOG
#include <stdio.h>
#define LOG fprintf
#define LOG_DEBUG stdout
#define LOG_ERROR stderr
#endif

#ifndef nullptr
#define nullptr NULL
#endif


//#include <sys/mman.h>   // shm_open
//#include <sys/stat.h>   // fstat, stat ...
//#include <unistd.h>     // ftruncate
//#include <fcntl.h>      // definition of O_XX constants: O_RDONLY, O_RDWR, O_CREATE ...
//#include <string.h>     // strlen
//#include <errno.h>      // errno

#include "shm_obj.hpp"

#include <list>

#define time_not_expaired 1 //TODO zzz


template <typename TV, typename TD, typename TF, int MAX_ID, int MAX_IDX>
class shm_2Darr {

public:
    typedef TV vers_arr_t[MAX_IDX];
    typedef TD vals_arr_t[MAX_IDX];
    typedef TF flgs_arr_t[MAX_IDX];

    typedef vers_arr_t all_vers_t[MAX_ID];
    typedef vals_arr_t all_vals_t[MAX_ID];
    typedef flgs_arr_t all_flgs_t[MAX_ID];

private:

    template <typename _TI, int _MAX_ITEM>
    class rarr_rdo {
        typedef _TI     __TIarr[_MAX_ITEM];
        __TIarr& _rarr;

    public:
        rarr_rdo(__TIarr& _ra): _rarr(_ra) {}
        _TI operator[](size_t id) const { //TODO const?
            LOG( LOG_DEBUG, "zzz rdo operator[] const %d \n", id );
            return _rarr[id];
        }
    };

public:
    class shm_refs_arr {

        typedef vers_arr_t& rvers_t;
        typedef vals_arr_t& rvals_t;
        typedef flgs_arr_t& rflgs_t;

    public:
        rvers_t rvers;
        rvals_t rvals;
        rflgs_t rflgs;

        shm_refs_arr(rvers_t _rvers, rvals_t _rvals, rflgs_t _rflgs) :
            rvers(_rvers), rvals(_rvals), rflgs(_rflgs)  {
        }

        shm_refs_arr(const shm_refs_arr& _ra) :
            rvers(_ra.rvers), rvals(_ra.rvals), rflgs(_ra.rflgs)  {
        }

    };

    class shm_arrays {


        shm_obj<all_vers_t> vers;
        shm_obj<all_vals_t> vals;
        shm_obj<all_flgs_t> flgs;
    public:
        shm_arrays(const char* suffix, int flags=O_RDONLY ) :
            vers( "vers-", suffix, flags ),
            vals( "vals-", suffix, flags ),
            flgs( "flgs-", suffix, flags | O_RDWR )  {
        }

        virtual ~shm_arrays() {
        }

        const shm_refs_arr operator[](int id) const {
            //accert (id > 0 && id < MAX_ID);
            LOG( LOG_DEBUG, "\nzzz 000 %d\t%p\t%p\n", id, &vals, ((all_vals_t&)vals)[id]);
            shm_refs_arr _trarr(((all_vers_t&)vers)[id], ((all_vals_t&)vals)[id], ((all_flgs_t&)flgs)[id] );
            return _trarr;
        }
    };

    class shm_data_reader  {
        shm_refs_arr rarr;
    public:
        shm_data_reader(const shm_refs_arr _rarr):
            rarr(_rarr) {}

    private:
        //TD value(size_t id, size_t n) const {
        //    return (reinterpret_cast<vap_data_arr_t*>(shmo_data_arr.mmapPtr)[id])[n];
        //};
        TD get_valid_data_by_num(int n) {
            //TODO need check type of version_holder it is must beatomic for now,
            // may we do it non atomic, volotile for example?
            TV version_before = rarr.rvers[n]; //it is atomic copy assignment
            if (version_before & 1) // If not even, the value in process of changing right now.
                return __zero();

            TD data = rarr.rvals[n];
            TF version_after = rarr.rvers[n]; // it is atomic copy assignment

            if  (version_before != version_after)  // versions is not sames
                // we may add extra check of version evenest
                //OR  (version_after & 1) //or versions is not even value is not correct
                return __zero();
            return data;
        }

        TD get_valid_val(int& n) {
            while(time_not_expaired) { //TODO zzz
                for (n = 0; n < MAX_IDX; n++) {
                    TD data = get_valid_data_by_num(n);
                    if ( data != __zero())
                        return data;
                }
                //never happened
                //TODO zzz
            }
            return __zero(); // or some server_down_ip ;)
        }

    public:
        TD check_or_get_new_val(TD cur_val, int& n) {
            if ( !(rarr.rflgs[n]) )
                if (cur_val == rarr.rvals[n]) // maybe need copy but I think it's not necessary
                    return cur_val;
            return get_valid_val(n);
        }

        void set_bflag(int n) {
            rarr.rflgs[n] = false;
        }

    private:
        TD __zero() {
            static TD __zero_data(0);
            return __zero_data;
        }

    };

    class shm_data_writer  {
        typedef std::list<TD> new_vals_list;
        typedef typename std::list<TD>::iterator new_vals_list_iter;
        //typename new_vals_list::iterator>
        shm_refs_arr rarr;
    public:
        shm_data_writer(const shm_refs_arr _rarr):
            rarr(_rarr) {}

        void update_vals_array(new_vals_list& _new_vals, int id) {

            // Look for those IPs that have not changed
            // in 99.999% it will be all of them
            for ( int ii = 0; ii < MAX_IDX; ii++ ) {
                TF bflg(true);
                for ( new_vals_list_iter i = _new_vals.begin(); i != _new_vals.end(); ) {
                    LOG( LOG_DEBUG,
                         "\nzzz-elb-dns updateVapWithFqdn: updating value %d from %s to %s",
                         ii, std::string(rarr.rvals[ii]).c_str(), std::string(*i).c_str());
                    if (*i == rarr.rvals[ii]) {
                        LOG( LOG_DEBUG, "\nzzz 333 %d\t%s\t%s",
                             ii, std::string(rarr.rvals[ii]).c_str(), std::string(*i).c_str());
                        //IP is valid
                        //TODO zzz-elb-dns here check if IP was marked as bad if so reset bad_ip_flag
                        // or just reset it

                        bflg = false;
                        i = _new_vals.erase( i );
                        break;
                    } else {
                        ++i;
                    }
                }
                //TODO zzz-elb-dns set bad_ip_flag for ip_arr[ii]
                rarr.rflgs[ii] = bflg;
            }

            LOG( LOG_DEBUG, "\nzzz-elb-dns updateVapWithFqdn: %lu \"fresh\" IPs in new_ip_list", _new_vals.size());

            // Look for those IPs that wasn't in the previous list
            for ( new_vals_list_iter i = _new_vals.begin(); i != _new_vals.end();) {
                TF bflg(true);
                int ii;
                for (ii=0; ii < MAX_IDX; ii++) {
                    if (( rarr.rvals[ii] == 0 ) || (rarr.rflgs[ii] == true)) { //TODO zzz-elb-dns
                        LOG( LOG_DEBUG,
                             "\nzzz-elb-dns updateVapWithFqdn: updating value %d from %s to %s",
                             ii, std::string(rarr.rvals[ii]).c_str(), std::string(*i).c_str());
                        rarr.rvers[ii]++;
                        rarr.rvals[ii] = *i; //TODO zzz-elb-dns it is copy assigned. need: ip_wrap& operator = (ip_wrap* _pip)
                        rarr.rvers[ii]++;
                        rarr.rflgs[ii] = bflg = false;

                        break;
                    }
                }

                if (!bflg) {
                    //LOG( LOG_DEBUG, "\nzzz-elb-dns updateVapWithFqdn: erasing ip %d", ii);
                    //LOG( LOG_DEBUG, "\nzzz-elb-dns updateVapWithFqdn: erasing ip %s",((std::string)*ptr).c_str());
                    i = _new_vals.erase( i );
                    LOG( LOG_DEBUG, "\nzzz-elb-dns updateVapWithFqdn: erasing value %d %s %lu",
                         ii, std::string(rarr.rvals[ii]).c_str(), _new_vals.size());
                } else {
                    //TODO it is never happend?
                    LOG( LOG_ERROR, "\nzzz-elb-dns updateVapWithFqdn: ERROR ");
                    ++i;
                }
            }
        }

    };

public:
   static shm_arrays& instance(const char* suffix, int flags=O_RDONLY){
        static shm_arrays _instance(suffix, flags);
        //TODO zzz check flags;
        return _instance;
    }

};

#endif
