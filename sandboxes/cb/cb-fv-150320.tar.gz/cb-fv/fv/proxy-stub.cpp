#include <iostream>

#include "shm_ip_consumer.hpp"

using namespace std;


int main(int argc, char* argv[]) {
    std::string str("the end!");

    do_consumer_test();

    cout   << str.c_str() << endl;
    return 0;
}
