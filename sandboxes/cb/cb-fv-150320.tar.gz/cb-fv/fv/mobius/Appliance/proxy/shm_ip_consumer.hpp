#ifndef SHM_IP_CONSUMER_H_INCLUDED
#define SHM_IP_CONSUMER_H_INCLUDED

//#include "flags_wrap.hpp"
#include "ip_wrap.hpp"

#define MAX_VAP 64
#define MAX_IP_PER_VAP 8

void do_consumer_test();
ip_wrap check_or_get_new_ip(ip_wrap cur_ip, int id, int& n);

#endif
