#include "shm_ip_consumer.hpp"
#include "ip_wrap.hpp"
#include "shm_2Darr.hpp"

using namespace std;

template <typename TD, int MAX_ID, int MAX_IDX>
class shm_reader {

private:
    typedef shm_2Darr< long, TD, long, MAX_VAP, MAX_IP_PER_VAP> __arr_t;
    typedef typename __arr_t::shm_arrays& __aref_t;

public:
    static TD check_or_get_new_val(const TD& cval, int id, int& idx) {
        static __aref_t __aref=__arr_t::instance("xxIPs",O_RDONLY);
        //TODO zzz need to check id and idx
        typename __arr_t::shm_data_reader dr(__aref[id]);
        return  dr.check_or_get_new_val(cval, idx);
    }

    static void set_bflag(int id, int idx) {
        static __aref_t __aref=__arr_t::instance("xxIPs",O_RDONLY);
        //TODO zzz need to check id and idx
        typename __arr_t::shm_data_reader dr(__aref[id]);
        return  dr.set_bflag(idx);
    }
};

typedef shm_reader<ip_wrap, MAX_VAP, MAX_IP_PER_VAP> shm_ip_reader_t;

void set_bflag(int id, int idx) {
    shm_ip_reader_t::set_bflag( id, idx);
};

ip_wrap check_or_get_new_ip(ip_wrap cval, int id, int& idx) {
    return shm_ip_reader_t::check_or_get_new_val(cval, id, idx);
};

void do_consumer_test() {
    ip_wrap ip("11.12.13.00");
    int n=1;
    while(1){
    fprintf(stdout, "%d\tip=%s\n",n,string(ip).c_str());
    ip_wrap ip2=check_or_get_new_ip(ip,1,n);
    fprintf(stdout, "%d\tip=%s\tip2=%s\n", n, string(ip).c_str(), string(ip2).c_str());
    ip=ip2;
    sleep(1);
    }

}
