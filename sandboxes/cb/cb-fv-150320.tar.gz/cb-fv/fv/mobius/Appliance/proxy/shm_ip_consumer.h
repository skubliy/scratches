#ifndef SHM_IP_CONSUMER_H_INCLUDED
#define SHM_IP_CONSUMER_H_INCLUDED

#include "ip_wrap.hpp"

#define MAX_VAP 64
#define MAX_IP_PER_VAP 8

ip_wrap check_or_get_new_val(ip_wrap cur_ip, size_t id, size_t n);

#endif
