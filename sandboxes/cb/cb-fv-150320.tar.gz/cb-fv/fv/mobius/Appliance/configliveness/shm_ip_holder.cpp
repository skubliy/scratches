#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <list>


#include "shm_ip_holder.hpp"
#include "shm_2Darr.hpp"


using namespace std;

/*typedef int ai64[64];
typedef shm_arr_hholder<long, long, long, MAX_VAP, MAX_IP_PER_VAP> shm_long_arr_t;
typedef shm_arr_hholder< long, ip_wrap, long, MAX_VAP, MAX_IP_PER_VAP> shm_ip_arr_t;

static shm_ip_arr_t OWNER("xxIPs",O_RDWR|O_CREAT);

void update_vap_ip_array(new_ip_list_t& _new_ip_list, size_t id) {
    shm_ip_arr_t::shm_arrays& arr=reinterpret_cast<shm_ip_arr_t::shm_arrays&>(*OWNER.pInstance);
    shm_ip_arr_t::shm_data_writer dw(arr[id]);
    dw.update_vals_array( _new_ip_list, id);
}
*/
template <typename TD>
static void update_val_array(list<TD>& _nv_lst, int _id) {
    typedef shm_2Darr< long, TD, long, MAX_VAP, MAX_IP_PER_VAP> __arr_t;
    typedef typename __arr_t::shm_arrays& __aref_t;
    static __aref_t __aref=__arr_t::instance("xxIPs",O_RDWR|O_CREAT);
    //TODO zzz need to check id and idx
    typename __arr_t::shm_data_writer dw(__aref[_id]);
    dw.update_vals_array( _nv_lst, _id);
};

void update_ip_array(new_ip_list_t& new_ip_list, int id){
    update_val_array(new_ip_list, id);
}

#if 1
template <typename TD>
void print_list(list<TD>& nvl) {
    typedef typename list<TD>::iterator __iterator_t;
    fprintf(stdout,"\n---------\n");
    for (__iterator_t i = nvl.begin(); i != nvl.end(); i++) {
        fprintf(stdout,"%s\t",std::string(*i).c_str());//std::string(*i).c_str());
    }
    fprintf(stdout,"\n=======\n");
};

template <typename TD>
void test () {
    list<TD> nv_lst;
    std::string str;
    for (int i=1; i<64; i++) {
        for (int j=1; j<8; j++) {
            TD x(i*100+j);
            // cout << std::string(*p).c_str()<<"\t";
            nv_lst.push_back(x);
            //TD xx(nv_lst.pop_back());
            //cout << xx << endl;
            //nv_lst.push_back(x);
        }
        cout << nv_lst.size()<<endl;
        print_list<TD>(nv_lst);

        update_val_array<TD>(nv_lst, i);

        print_list<TD>(nv_lst);

        cout << endl <<nv_lst.size()<<endl;
        //cin >> str; cout << str;
    }
};

void owner_do_test() {
    test<ip_wrap>();
}


#endif // 1
