#include <iostream>
#include <stdio.h>
#include <list>

#include "shm_ip_holder.hpp"
#include "ip_wrap.hpp"



using namespace std;

int main(int argc, char* argv[]) {

    string str="----\n";
    cout << str << endl;
    owner_do_test();
    cout << "\n===============\n";
    cin >> str;
    cout << str << endl;
    return 0;
}
